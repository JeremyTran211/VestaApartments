const config = {
    db: {
      host: "ec2-18-212-157-140.compute-1.amazonaws.com",
      user: "admin",
      password: "921359982@Gators",
      database: "SFStudentRent",
      connectTimeout: 60000,
      port: 3306
    },
    listPerPage: 50,
  };
  module.exports = config;